﻿namespace Atbash.Api.Models
{
    public class OperationRequest
    {
        public string Text { get; set; } = "";
        public string Source { get; set; } = "Manual";
    }
}
   